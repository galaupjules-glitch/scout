import { cli, Strategy } from '@jackwener/opencli/registry';
import {
    CHATGPT_DOMAIN,
    CHATGPT_MODEL_CHOICES,
    navigateToProject,
    selectChatGPTModel,
} from './utils.js';

export const modelCommand = cli({
    site: 'chatgpt',
    name: 'model',
    access: 'write',
    description: 'Switch ChatGPT web model or intelligence level (GPT-5.6 Pro, fast, balanced, advanced, very-high, pro)',
    domain: CHATGPT_DOMAIN,
    strategy: Strategy.COOKIE,
    browser: true,
    siteSession: 'persistent',
    navigateBefore: false,
    args: [
        { name: 'model', required: true, positional: true, help: 'ChatGPT model or intelligence level to switch to', choices: CHATGPT_MODEL_CHOICES },
        { name: 'project', valueRequired: true, help: 'Open a ChatGPT project ID or /g/g-p-<id> URL before switching intelligence level' },
    ],
    columns: ['Status', 'Model'],
    func: async (page, kwargs) => {
        if (kwargs.project) {
            await navigateToProject(page, kwargs.project);
        }
        const result = await selectChatGPTModel(page, kwargs.model);
        return [{ Status: result.Status, Model: result.Model }];
    },
});
