import { cli, Strategy } from '@jackwener/opencli/registry';
import { ArgumentError } from '@jackwener/opencli/errors';
import { browserFetch } from './_shared/browser-fetch.js';
import { toUnixSeconds, validateTiming } from './_shared/timing.js';
cli({
    site: 'douyin',
    name: 'update',
    access: 'write',
    description: '更新视频信息',
    domain: 'creator.douyin.com',
    strategy: Strategy.COOKIE,
    args: [
        { name: 'aweme_id', required: true, positional: true, help: '抖音作品 ID（aweme_id，可从作品 URL 末尾获取）' },
        { name: 'reschedule', default: '', help: '新的发布时间（ISO8601 或 Unix 秒）' },
        { name: 'caption', default: '', help: '新的正文内容' },
    ],
    columns: ['status'],
    func: async (page, kwargs) => {
        if (!kwargs.reschedule && !kwargs.caption) {
            throw new ArgumentError('必须提供 --reschedule 或 --caption');
        }
        if (kwargs.reschedule) {
            const newTime = toUnixSeconds(kwargs.reschedule);
            validateTiming(newTime);
            await browserFetch(page, 'POST', 'https://creator.douyin.com/web/api/media/update/timer/?aid=1128', { body: { aweme_id: kwargs.aweme_id, publish_time: newTime } });
        }
        if (kwargs.caption) {
            await browserFetch(page, 'POST', 'https://creator.douyin.com/web/api/media/update/desc/?aid=1128', { body: { aweme_id: kwargs.aweme_id, desc: kwargs.caption } });
        }
        return [{ status: '✅ 更新成功' }];
    },
});
